var button = document.getElementById('moving-button');

button.addEventListener('mouseover', function() {
  var buttonWidth = button.offsetWidth;
  var buttonHeight = button.offsetHeight;
  var windowWidth = window.innerWidth;
  var windowHeight = window.innerHeight;

  var newX = Math.floor(Math.random() * (windowWidth - buttonWidth));
  var newY = Math.floor(Math.random() * (windowHeight - buttonHeight));

  button.style.left = newX + 'px';
  button.style.top = newY + 'px';
});